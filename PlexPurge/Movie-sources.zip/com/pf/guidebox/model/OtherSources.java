
package com.pf.guidebox.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class OtherSources {

    private List<TvOnDemand> tvOnDemand = new ArrayList<TvOnDemand>();
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * 
     * @return
     *     The tvOnDemand
     */
    public List<TvOnDemand> getTvOnDemand() {
        return tvOnDemand;
    }

    /**
     * 
     * @param tvOnDemand
     *     The tv_on_demand
     */
    public void setTvOnDemand(List<TvOnDemand> tvOnDemand) {
        this.tvOnDemand = tvOnDemand;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}

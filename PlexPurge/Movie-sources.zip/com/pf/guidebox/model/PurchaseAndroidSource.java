
package com.pf.guidebox.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class PurchaseAndroidSource {

    private String source;
    private String displayName;
    private String link;
    private String appName;
    private Long appLink;
    private Long appRequired;
    private String appDownloadLink;
    private List<Format__> formats = new ArrayList<Format__>();
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * 
     * @return
     *     The source
     */
    public String getSource() {
        return source;
    }

    /**
     * 
     * @param source
     *     The source
     */
    public void setSource(String source) {
        this.source = source;
    }

    /**
     * 
     * @return
     *     The displayName
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * 
     * @param displayName
     *     The display_name
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    /**
     * 
     * @return
     *     The link
     */
    public String getLink() {
        return link;
    }

    /**
     * 
     * @param link
     *     The link
     */
    public void setLink(String link) {
        this.link = link;
    }

    /**
     * 
     * @return
     *     The appName
     */
    public String getAppName() {
        return appName;
    }

    /**
     * 
     * @param appName
     *     The app_name
     */
    public void setAppName(String appName) {
        this.appName = appName;
    }

    /**
     * 
     * @return
     *     The appLink
     */
    public Long getAppLink() {
        return appLink;
    }

    /**
     * 
     * @param appLink
     *     The app_link
     */
    public void setAppLink(Long appLink) {
        this.appLink = appLink;
    }

    /**
     * 
     * @return
     *     The appRequired
     */
    public Long getAppRequired() {
        return appRequired;
    }

    /**
     * 
     * @param appRequired
     *     The app_required
     */
    public void setAppRequired(Long appRequired) {
        this.appRequired = appRequired;
    }

    /**
     * 
     * @return
     *     The appDownloadLink
     */
    public String getAppDownloadLink() {
        return appDownloadLink;
    }

    /**
     * 
     * @param appDownloadLink
     *     The app_download_link
     */
    public void setAppDownloadLink(String appDownloadLink) {
        this.appDownloadLink = appDownloadLink;
    }

    /**
     * 
     * @return
     *     The formats
     */
    public List<Format__> getFormats() {
        return formats;
    }

    /**
     * 
     * @param formats
     *     The formats
     */
    public void setFormats(List<Format__> formats) {
        this.formats = formats;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}


package com.pf.guidebox.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class Movie {

    private Long id;
    private String title;
    private Long releaseYear;
    private Long themoviedb;
    private String originalTitle;
    private List<String> alternateTitles = new ArrayList<String>();
    private String imdb;
    private Boolean preOrder;
    private String releaseDate;
    private String rating;
    private Long rottentomatoes;
    private String freebase;
    private Long wikipediaId;
    private String metacritic;
    private Object commonSenseMedia;
    private String overview;
    private String poster120x171;
    private String poster240x342;
    private String poster400x570;
    private Social social;
    private List<Genre> genres = new ArrayList<Genre>();
    private List<Tag> tags = new ArrayList<Tag>();
    private Long duration;
    private Trailers trailers;
    private List<Writer> writers = new ArrayList<Writer>();
    private List<Director> directors = new ArrayList<Director>();
    private List<Cast> cast = new ArrayList<Cast>();
    private List<Object> freeWebSources = new ArrayList<Object>();
    private List<Object> freeIosSources = new ArrayList<Object>();
    private List<Object> freeAndroidSources = new ArrayList<Object>();
    private List<TvEverywhereWebSource> tvEverywhereWebSources = new ArrayList<TvEverywhereWebSource>();
    private List<TvEverywhereIosSource> tvEverywhereIosSources = new ArrayList<TvEverywhereIosSource>();
    private List<TvEverywhereAndroidSource> tvEverywhereAndroidSources = new ArrayList<TvEverywhereAndroidSource>();
    private List<SubscriptionWebSource> subscriptionWebSources = new ArrayList<SubscriptionWebSource>();
    private List<SubscriptionIosSource> subscriptionIosSources = new ArrayList<SubscriptionIosSource>();
    private List<SubscriptionAndroidSource> subscriptionAndroidSources = new ArrayList<SubscriptionAndroidSource>();
    private List<PurchaseWebSource> purchaseWebSources = new ArrayList<PurchaseWebSource>();
    private List<PurchaseIosSource> purchaseIosSources = new ArrayList<PurchaseIosSource>();
    private List<PurchaseAndroidSource> purchaseAndroidSources = new ArrayList<PurchaseAndroidSource>();
    private OtherSources otherSources;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * 
     * @return
     *     The id
     */
    public Long getId() {
        return id;
    }

    /**
     * 
     * @param id
     *     The id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 
     * @return
     *     The title
     */
    public String getTitle() {
        return title;
    }

    /**
     * 
     * @param title
     *     The title
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * 
     * @return
     *     The releaseYear
     */
    public Long getReleaseYear() {
        return releaseYear;
    }

    /**
     * 
     * @param releaseYear
     *     The release_year
     */
    public void setReleaseYear(Long releaseYear) {
        this.releaseYear = releaseYear;
    }

    /**
     * 
     * @return
     *     The themoviedb
     */
    public Long getThemoviedb() {
        return themoviedb;
    }

    /**
     * 
     * @param themoviedb
     *     The themoviedb
     */
    public void setThemoviedb(Long themoviedb) {
        this.themoviedb = themoviedb;
    }

    /**
     * 
     * @return
     *     The originalTitle
     */
    public String getOriginalTitle() {
        return originalTitle;
    }

    /**
     * 
     * @param originalTitle
     *     The original_title
     */
    public void setOriginalTitle(String originalTitle) {
        this.originalTitle = originalTitle;
    }

    /**
     * 
     * @return
     *     The alternateTitles
     */
    public List<String> getAlternateTitles() {
        return alternateTitles;
    }

    /**
     * 
     * @param alternateTitles
     *     The alternate_titles
     */
    public void setAlternateTitles(List<String> alternateTitles) {
        this.alternateTitles = alternateTitles;
    }

    /**
     * 
     * @return
     *     The imdb
     */
    public String getImdb() {
        return imdb;
    }

    /**
     * 
     * @param imdb
     *     The imdb
     */
    public void setImdb(String imdb) {
        this.imdb = imdb;
    }

    /**
     * 
     * @return
     *     The preOrder
     */
    public Boolean getPreOrder() {
        return preOrder;
    }

    /**
     * 
     * @param preOrder
     *     The pre_order
     */
    public void setPreOrder(Boolean preOrder) {
        this.preOrder = preOrder;
    }

    /**
     * 
     * @return
     *     The releaseDate
     */
    public String getReleaseDate() {
        return releaseDate;
    }

    /**
     * 
     * @param releaseDate
     *     The release_date
     */
    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    /**
     * 
     * @return
     *     The rating
     */
    public String getRating() {
        return rating;
    }

    /**
     * 
     * @param rating
     *     The rating
     */
    public void setRating(String rating) {
        this.rating = rating;
    }

    /**
     * 
     * @return
     *     The rottentomatoes
     */
    public Long getRottentomatoes() {
        return rottentomatoes;
    }

    /**
     * 
     * @param rottentomatoes
     *     The rottentomatoes
     */
    public void setRottentomatoes(Long rottentomatoes) {
        this.rottentomatoes = rottentomatoes;
    }

    /**
     * 
     * @return
     *     The freebase
     */
    public String getFreebase() {
        return freebase;
    }

    /**
     * 
     * @param freebase
     *     The freebase
     */
    public void setFreebase(String freebase) {
        this.freebase = freebase;
    }

    /**
     * 
     * @return
     *     The wikipediaId
     */
    public Long getWikipediaId() {
        return wikipediaId;
    }

    /**
     * 
     * @param wikipediaId
     *     The wikipedia_id
     */
    public void setWikipediaId(Long wikipediaId) {
        this.wikipediaId = wikipediaId;
    }

    /**
     * 
     * @return
     *     The metacritic
     */
    public String getMetacritic() {
        return metacritic;
    }

    /**
     * 
     * @param metacritic
     *     The metacritic
     */
    public void setMetacritic(String metacritic) {
        this.metacritic = metacritic;
    }

    /**
     * 
     * @return
     *     The commonSenseMedia
     */
    public Object getCommonSenseMedia() {
        return commonSenseMedia;
    }

    /**
     * 
     * @param commonSenseMedia
     *     The common_sense_media
     */
    public void setCommonSenseMedia(Object commonSenseMedia) {
        this.commonSenseMedia = commonSenseMedia;
    }

    /**
     * 
     * @return
     *     The overview
     */
    public String getOverview() {
        return overview;
    }

    /**
     * 
     * @param overview
     *     The overview
     */
    public void setOverview(String overview) {
        this.overview = overview;
    }

    /**
     * 
     * @return
     *     The poster120x171
     */
    public String getPoster120x171() {
        return poster120x171;
    }

    /**
     * 
     * @param poster120x171
     *     The poster_120x171
     */
    public void setPoster120x171(String poster120x171) {
        this.poster120x171 = poster120x171;
    }

    /**
     * 
     * @return
     *     The poster240x342
     */
    public String getPoster240x342() {
        return poster240x342;
    }

    /**
     * 
     * @param poster240x342
     *     The poster_240x342
     */
    public void setPoster240x342(String poster240x342) {
        this.poster240x342 = poster240x342;
    }

    /**
     * 
     * @return
     *     The poster400x570
     */
    public String getPoster400x570() {
        return poster400x570;
    }

    /**
     * 
     * @param poster400x570
     *     The poster_400x570
     */
    public void setPoster400x570(String poster400x570) {
        this.poster400x570 = poster400x570;
    }

    /**
     * 
     * @return
     *     The social
     */
    public Social getSocial() {
        return social;
    }

    /**
     * 
     * @param social
     *     The social
     */
    public void setSocial(Social social) {
        this.social = social;
    }

    /**
     * 
     * @return
     *     The genres
     */
    public List<Genre> getGenres() {
        return genres;
    }

    /**
     * 
     * @param genres
     *     The genres
     */
    public void setGenres(List<Genre> genres) {
        this.genres = genres;
    }

    /**
     * 
     * @return
     *     The tags
     */
    public List<Tag> getTags() {
        return tags;
    }

    /**
     * 
     * @param tags
     *     The tags
     */
    public void setTags(List<Tag> tags) {
        this.tags = tags;
    }

    /**
     * 
     * @return
     *     The duration
     */
    public Long getDuration() {
        return duration;
    }

    /**
     * 
     * @param duration
     *     The duration
     */
    public void setDuration(Long duration) {
        this.duration = duration;
    }

    /**
     * 
     * @return
     *     The trailers
     */
    public Trailers getTrailers() {
        return trailers;
    }

    /**
     * 
     * @param trailers
     *     The trailers
     */
    public void setTrailers(Trailers trailers) {
        this.trailers = trailers;
    }

    /**
     * 
     * @return
     *     The writers
     */
    public List<Writer> getWriters() {
        return writers;
    }

    /**
     * 
     * @param writers
     *     The writers
     */
    public void setWriters(List<Writer> writers) {
        this.writers = writers;
    }

    /**
     * 
     * @return
     *     The directors
     */
    public List<Director> getDirectors() {
        return directors;
    }

    /**
     * 
     * @param directors
     *     The directors
     */
    public void setDirectors(List<Director> directors) {
        this.directors = directors;
    }

    /**
     * 
     * @return
     *     The cast
     */
    public List<Cast> getCast() {
        return cast;
    }

    /**
     * 
     * @param cast
     *     The cast
     */
    public void setCast(List<Cast> cast) {
        this.cast = cast;
    }

    /**
     * 
     * @return
     *     The freeWebSources
     */
    public List<Object> getFreeWebSources() {
        return freeWebSources;
    }

    /**
     * 
     * @param freeWebSources
     *     The free_web_sources
     */
    public void setFreeWebSources(List<Object> freeWebSources) {
        this.freeWebSources = freeWebSources;
    }

    /**
     * 
     * @return
     *     The freeIosSources
     */
    public List<Object> getFreeIosSources() {
        return freeIosSources;
    }

    /**
     * 
     * @param freeIosSources
     *     The free_ios_sources
     */
    public void setFreeIosSources(List<Object> freeIosSources) {
        this.freeIosSources = freeIosSources;
    }

    /**
     * 
     * @return
     *     The freeAndroidSources
     */
    public List<Object> getFreeAndroidSources() {
        return freeAndroidSources;
    }

    /**
     * 
     * @param freeAndroidSources
     *     The free_android_sources
     */
    public void setFreeAndroidSources(List<Object> freeAndroidSources) {
        this.freeAndroidSources = freeAndroidSources;
    }

    /**
     * 
     * @return
     *     The tvEverywhereWebSources
     */
    public List<TvEverywhereWebSource> getTvEverywhereWebSources() {
        return tvEverywhereWebSources;
    }

    /**
     * 
     * @param tvEverywhereWebSources
     *     The tv_everywhere_web_sources
     */
    public void setTvEverywhereWebSources(List<TvEverywhereWebSource> tvEverywhereWebSources) {
        this.tvEverywhereWebSources = tvEverywhereWebSources;
    }

    /**
     * 
     * @return
     *     The tvEverywhereIosSources
     */
    public List<TvEverywhereIosSource> getTvEverywhereIosSources() {
        return tvEverywhereIosSources;
    }

    /**
     * 
     * @param tvEverywhereIosSources
     *     The tv_everywhere_ios_sources
     */
    public void setTvEverywhereIosSources(List<TvEverywhereIosSource> tvEverywhereIosSources) {
        this.tvEverywhereIosSources = tvEverywhereIosSources;
    }

    /**
     * 
     * @return
     *     The tvEverywhereAndroidSources
     */
    public List<TvEverywhereAndroidSource> getTvEverywhereAndroidSources() {
        return tvEverywhereAndroidSources;
    }

    /**
     * 
     * @param tvEverywhereAndroidSources
     *     The tv_everywhere_android_sources
     */
    public void setTvEverywhereAndroidSources(List<TvEverywhereAndroidSource> tvEverywhereAndroidSources) {
        this.tvEverywhereAndroidSources = tvEverywhereAndroidSources;
    }

    /**
     * 
     * @return
     *     The subscriptionWebSources
     */
    public List<SubscriptionWebSource> getSubscriptionWebSources() {
        return subscriptionWebSources;
    }

    /**
     * 
     * @param subscriptionWebSources
     *     The subscription_web_sources
     */
    public void setSubscriptionWebSources(List<SubscriptionWebSource> subscriptionWebSources) {
        this.subscriptionWebSources = subscriptionWebSources;
    }

    /**
     * 
     * @return
     *     The subscriptionIosSources
     */
    public List<SubscriptionIosSource> getSubscriptionIosSources() {
        return subscriptionIosSources;
    }

    /**
     * 
     * @param subscriptionIosSources
     *     The subscription_ios_sources
     */
    public void setSubscriptionIosSources(List<SubscriptionIosSource> subscriptionIosSources) {
        this.subscriptionIosSources = subscriptionIosSources;
    }

    /**
     * 
     * @return
     *     The subscriptionAndroidSources
     */
    public List<SubscriptionAndroidSource> getSubscriptionAndroidSources() {
        return subscriptionAndroidSources;
    }

    /**
     * 
     * @param subscriptionAndroidSources
     *     The subscription_android_sources
     */
    public void setSubscriptionAndroidSources(List<SubscriptionAndroidSource> subscriptionAndroidSources) {
        this.subscriptionAndroidSources = subscriptionAndroidSources;
    }

    /**
     * 
     * @return
     *     The purchaseWebSources
     */
    public List<PurchaseWebSource> getPurchaseWebSources() {
        return purchaseWebSources;
    }

    /**
     * 
     * @param purchaseWebSources
     *     The purchase_web_sources
     */
    public void setPurchaseWebSources(List<PurchaseWebSource> purchaseWebSources) {
        this.purchaseWebSources = purchaseWebSources;
    }

    /**
     * 
     * @return
     *     The purchaseIosSources
     */
    public List<PurchaseIosSource> getPurchaseIosSources() {
        return purchaseIosSources;
    }

    /**
     * 
     * @param purchaseIosSources
     *     The purchase_ios_sources
     */
    public void setPurchaseIosSources(List<PurchaseIosSource> purchaseIosSources) {
        this.purchaseIosSources = purchaseIosSources;
    }

    /**
     * 
     * @return
     *     The purchaseAndroidSources
     */
    public List<PurchaseAndroidSource> getPurchaseAndroidSources() {
        return purchaseAndroidSources;
    }

    /**
     * 
     * @param purchaseAndroidSources
     *     The purchase_android_sources
     */
    public void setPurchaseAndroidSources(List<PurchaseAndroidSource> purchaseAndroidSources) {
        this.purchaseAndroidSources = purchaseAndroidSources;
    }

    /**
     * 
     * @return
     *     The otherSources
     */
    public OtherSources getOtherSources() {
        return otherSources;
    }

    /**
     * 
     * @param otherSources
     *     The other_sources
     */
    public void setOtherSources(OtherSources otherSources) {
        this.otherSources = otherSources;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}


package com.pf.guidebox.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class Trailers {

    private List<Web> web = new ArrayList<Web>();
    private List<Io> ios = new ArrayList<Io>();
    private List<Android> android = new ArrayList<Android>();
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * 
     * @return
     *     The web
     */
    public List<Web> getWeb() {
        return web;
    }

    /**
     * 
     * @param web
     *     The web
     */
    public void setWeb(List<Web> web) {
        this.web = web;
    }

    /**
     * 
     * @return
     *     The ios
     */
    public List<Io> getIos() {
        return ios;
    }

    /**
     * 
     * @param ios
     *     The ios
     */
    public void setIos(List<Io> ios) {
        this.ios = ios;
    }

    /**
     * 
     * @return
     *     The android
     */
    public List<Android> getAndroid() {
        return android;
    }

    /**
     * 
     * @param android
     *     The android
     */
    public void setAndroid(List<Android> android) {
        this.android = android;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
